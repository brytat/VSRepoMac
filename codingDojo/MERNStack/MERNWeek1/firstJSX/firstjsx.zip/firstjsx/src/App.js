import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h3>Things I need to do:</h3>
      <ul>
        <li>Get a Black belt in the MERN stack</li>
        <li>Get a dream job doing software development</li>
        <li>Work on my personal coding projects</li>
      </ul>
    </div>
  );
}

export default App;